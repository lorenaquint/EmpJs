<?php

	echo "¡Tu formulario ha sido enviado correctamente!";

?>