//VAR se utiliza para hacer variables globales
var nombre = "Juan";
if (nombre == "Juan") {
    //LET se utiliza para hacer variables en bloques de código dentro de una instrucción ya sea una función o una condición
    var nombre_1 = "Pedro";
    console.log("Dentro de la condicion nombre:", nombre_1);
}
console.log("Fuera de la condicion nombre:", nombre);
