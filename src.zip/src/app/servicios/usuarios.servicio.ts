import { Injectable } from '@angular/core';

import { Http, Response, Headers } from '@angular/http';

import 'rxjs/add/operator/map';

import { Observable } from 'rxjs/Observable';

@Injectable()

export class ServicioUsuarios{

	/*=============================================
	PETICIONES HTTP PARA TRAER EL ARCHIVO JSON
	=============================================*/

	public url:string;

	constructor(private _http:Http){

		this.url = "http://tutorialesatualcance.com/usuarios.json";	
	
	}

	login(){

		//Cuando enviamos peticiones POST debemos declarar el tipo de contenido que vamos a enviar a través de la cabecera HTTP

		let cabecera = new Headers({"Content-Type":"application/json"})

		return this._http.post(this.url, {cabecera: cabecera}).map(resultado => resultado.json())	

	}



}