//Los servicios son clases con un objetivo claro que nos facilitan la reutilización de código, y son un tipo de módulo que nos va a permitir separa el trabajo con APIS, con HTTP, con Bases de datos y a través de la inyección de dependencias podemos enviar la información y utilizarla en los principales componentes.

//Importamos el decorador Injectable, para poder inyectar nuestra clase mediante la inyección de dependencias en los componentes
import { Injectable } from '@angular/core';

// Si vamos a hacer peticiones HTTP debemos importar los siguientes módulos:
import { Http, Response, Headers } from '@angular/http';

// Tambien importamos una librería para Mapear las respuestas HTTP
import 'rxjs/add/operator/map';

// Importamos también el objeto Observable que nos va a permitir utilizar rxjs que es la respuesta del mapeo y trabajar con ello
import { Observable } from 'rxjs/Observable';

//Definimos el decorador injectable
@Injectable()

// Exportamos la clase del servicio
export class ServicioSlide{

	/*=============================================
	PRUEBA DEL SERVICIO
	=============================================*/

	// public ruta_foto = "assets/img/slide/slide01.jpg";

	// prueba(){

	// 	return this.ruta_foto;

	// }

	/*=============================================
	PETICIONES HTTP PARA TRAER EL ARCHIVO JSON
	=============================================*/

	public url:string;

	// Para poder utilizar el servicio HTTP debemos tener una propiedad HTTP en nuestra clase
	constructor(private _http:Http){

		//Instalar el componente Allow-Control-Allow-Origin: *	
		this.url = "http://tutorialesatualcance.com/slide.json";	
	
	}

	tomarJsonSlide(){

		// Hacemos una peticion por GET a esa URL devolviendo la respuesta que nos dé el método, haciendo una llamada al objeto http que ya tenemos cargado en la propiedad privada.

		//Como parámetros debemos pasar la URL y capturamos la respuesta que nos de esa peticion por GET con el método MAP()

		//En callback con una función de flecha recogemos la respuesta que viene en el primer parámetro y lo convertimos en formato json utilizando el método JSON.

		return this._http.get(this.url).map(resultado => resultado.json())	

	}


}