//Los servicios son clases con un objetivo claro que nos facilitan la reutilización de código, y son un tipo de módulo que nos va a permitir separa el trabajo con APIS, con HTTP, con Bases de datos y a través de la inyección de dependencias podemos enviar la información y utilizarla en los principales componentes.

//Importamos el decorador Injectable, para poder inyectar nuestra clase mediante la inyección de dependencias en los componentes
import { Injectable } from '@angular/core';

// Si vamos a hacer peticiones HTTP debemos importar los siguientes módulos:
import { Http, Response, Headers } from '@angular/http';

// Tambien importamos una librería para Mapear las respuestas HTTP
import 'rxjs/add/operator/map';

// Importamos también el objeto Observable que nos va a permitir utilizar rxjs que es la respuesta del mapeo y trabajar con ello
import { Observable } from 'rxjs/Observable';

//Definimos el decorador injectable
@Injectable()

// Exportamos la clase del servicio
export class ServicioGaleria{

	/*=============================================
	PRUEBA DEL SERVICIO
	=============================================*/

	// public ruta_foto = "assets/img/galeria/01.jpg";

	// prueba(){

	// 	return this.ruta_foto;

	// }

	/*=============================================
	PETICIONES HTTP PARA TRAER EL ARCHIVO JSON
	=============================================*/

	public url:string;

	constructor(private _http:Http){

		this.url = "http://tutorialesatualcance.com/galeria.json";	
	
	}

	tomarJsonGaleria(){

		return this._http.get(this.url).map(resultado => resultado.json())	

	}



}