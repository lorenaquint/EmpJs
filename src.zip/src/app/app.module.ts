/*=============================================
Las aplicaciones de Angular son modulares y Angular tiene su propio sistema de modularidad llamado NgModules. 
Cada aplicación Angular tiene al menos una clase NgModule, el módulo raíz, nombrado convencionalmente AppModule.          
=============================================*/

//Importamos la clase BrowserModule, para buscar módulos de angular.
import { BrowserModule } from '@angular/platform-browser';

//Importamos la clase NgModule que es el módulo raíz.
import { NgModule } from '@angular/core';

//Agregar HTTPModule para trabajar con cabeceras HTTP
import { HttpModule } from '@angular/http';

//Agregar para trabajar con formularios
import { FormsModule } from '@angular/forms';

//Importamos el componente que es donde estará la vista principal de la aplicación
import { AppComponent } from './app.component';

import { IndexComponente } from './componentes/index';

import { SlideComponente } from './componentes/slide';

import { GaleriaComponente } from './componentes/galeria';

import { MouseComponente } from './componentes/mouse';

import { ScrollComponente } from './componentes/scroll';

import { FormularioComponente } from './componentes/formulario';

import { ApiComponente } from './componentes/api';

//Importamos los módulos de ruta
import { routing, appRoutingProviders } from './app.rutas';

//Los decoradores son funciones que modifican clases de JavaScript. Angular tiene muchos decoradores que adjuntan metadatos de las clases para que sepa lo que significan esas clases y cómo deben funcionar.

@NgModule({

	//Las declaraciones son las clases de vista que pertenecen a este módulo. Angular tiene tres tipos de clases de vista: components, directives, and pipes.  
  declarations: [
    AppComponent,
    IndexComponente,
    SlideComponente,
    GaleriaComponente,
    MouseComponente,
    ScrollComponente,
    FormularioComponente,
    ApiComponente

  ],
	//Importamos otros módulos cuyas clases exportadas sean necesarias para las plantillas de componentes declaradas en este módulo.
  imports: [
    BrowserModule,
     //cargo el modulo de rutas
    routing,
    //Cargo el módulo de HTTP
    HttpModule,
    //Cargo el módulo de formularios
    FormsModule

  ],
   // Los proveedores son los creadores de servicios que este módulo contribuye a la recolección global de servicios; Se vuelven accesibles en todas las partes de la aplicación. Esto lo habilitamos cuando invocamos servicios desde una base de datos.
  providers: [
  //Cargo el servicio que hace que el router se lance y funcione cada ruta cuando la llamemos
  appRoutingProviders
  ],
  bootstrap: [AppComponent]
})

//Exportamos la clase del módulo raíz para poder ser invocada en otros archivos
export class AppModule { }
