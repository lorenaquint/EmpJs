window.onload = function(){

console.log("hola mundo");
	
}

