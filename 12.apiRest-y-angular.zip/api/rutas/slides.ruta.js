"use strict"
// Cargamos la dependencia de Express
var express = require("express");

//Cargamos el módulo del controlador
var ControladorSlides = require("../controladores/slides.controlador.js");

// Cargamos el Router de Express.js y con esto podemos crear rutas para nuestra API REST.
var api = express.Router();

//Cargamos la dependencia para subir ficheros
var multipart = require("connect-multiparty");

var fichero = multipart({
	// Ruta donde se suben las imágenes
	uploadDir: "./ficheros/slide"

})

var md_aut = require("../token/aut.js");

//Creamos la ruta con el método GET, para pasar el método que va a tener que cargar la página cuando hagamos la petición HTTP de esa ruta
api.get("/probando-controlador-slides", ControladorSlides.pruebaSlides);
//Creamos la ruta para subir un Slide utilizando el Token de aut, y la ruta donde se van a subir las imágenes
api.post("/crear-slide", [md_aut.autenticacion, fichero], ControladorSlides.crearSlide);

api.get("/mostrar-slides",  ControladorSlides.mostrarSlides);

api.put("/actualizar-slide/:id", [md_aut.autenticacion, fichero], ControladorSlides.actualizarSlide);

api.delete("/borrar-slide/:id", md_aut.autenticacion, ControladorSlides.borrarSlide);

api.get("/tomar-imagen-slide/:imagen", ControladorSlides.tomarImagenSlide);


//EXportamos el módulo api
module.exports = api;