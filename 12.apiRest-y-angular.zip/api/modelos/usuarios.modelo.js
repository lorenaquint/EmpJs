"use strict"
//Requerimos la dependencia Mongoose para acceder a la base de datos
var mongoose = require("mongoose");
// El objeto de tipo Esquema nos permite guardar en una colección concreta y en un documento concreto dentro de esa colección
var Schema = mongoose.Schema;

//Creamos el Esquema con los respectivos atributos
var UsuariosSchema = Schema({
	usuario: String,
	password: String
})

// El objeto Usuarios va poder ser instanciado y automáticamente le vamos asignando los valores del Esquema
module.exports = mongoose.model("Usuarios", UsuariosSchema);