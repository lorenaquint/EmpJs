export class ListaUsuarios{

constructor(

	public usuario:string,
	public password:string

	){}

}