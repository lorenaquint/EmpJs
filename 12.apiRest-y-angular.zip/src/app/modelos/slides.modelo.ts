export class ItemSlides{

constructor(

	public imagen:string,
	public titulo:string,
	public descripcion:string

	){}

}