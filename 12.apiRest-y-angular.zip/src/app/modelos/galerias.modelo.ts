export class ItemGalerias{

constructor(

	public foto:string

	){}

}