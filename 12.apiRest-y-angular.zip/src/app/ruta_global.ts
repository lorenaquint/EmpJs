export var Ruta = {
	url: "http://localhost:1234/api/"
	//url: "http://juan-apirest.openode.io/api/"
}